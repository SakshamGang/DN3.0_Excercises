import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Book[] books = new Book[] {
            new Book(1, "Book A", "Author A"),
            new Book(2, "Book B", "Author B"),
            new Book(3, "Book C", "Author C"),
            new Book(4, "Book D", "Author D"),
            new Book(5, "Book E", "Author E")
        };

        LinearSearch linearSearch = new LinearSearch();
        Book book = linearSearch.search(books, "Book C");
        if (book!= null) {
            System.out.println("Linear Search: Book found - " + book.title);
        } else {
            System.out.println("Linear Search: Book not found");
        }

        BinarySearch binarySearch = new BinarySearch();
        book = binarySearch.search(books, "Book C");
        if (book!= null) {
            System.out.println("Binary Search: Book found - " + book.title);
        } else {
            System.out.println("Binary Search: Book not found");
        }
    }
}