import java.util.*;

public class BinarySearch {
    public Book search(Book[] books, String title) {
        Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));
        int low = 0;
        int high = books.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            if (books[mid].title.equalsIgnoreCase(title)) {
                return books[mid];
            } else if (books[mid].title.compareToIgnoreCase(title) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }
}