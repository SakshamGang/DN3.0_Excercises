public class LinearSearch {
    public static int search(Product[] products, int targetProductId) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].productId == targetProductId) {
                return i;
            }
        }
        return -1; // not found
    }
}