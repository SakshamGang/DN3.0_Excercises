public class BinarySearch {
    public static int search(Product[] products, int targetProductId) {
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].productId == targetProductId) {
                return mid;
            } else if (products[mid].productId < targetProductId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // not found
    }
}