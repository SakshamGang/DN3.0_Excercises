public class WordDocumentImpl extends WordDocument {
    public WordDocumentImpl() {
        System.out.println("Creating Word document...");
    }
}