public class DependencyInjectionTest {
    public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();
        CustomerService customerService = new CustomerService(customerRepository);

        String customerName = customerService.findCustomerById(2);
        System.out.println("Customer Name: " + customerName);
    }
}