public class StripeGateway {
    public void chargeCard(double amount) {
        System.out.println("Charging Stripe card for $" + amount);
    }
}